from transformers import AutoModelForCausalLM, AutoTokenizer

# Load the model and tokenizer
model = AutoModelForCausalLM.from_pretrained('dpo_model_1e-05_0.1')
tokenizer = AutoTokenizer.from_pretrained('dpo_model_1e-05_0.1/tokenizer.json')

def generate_response(user_input):
    inputs = tokenizer.encode(user_input, return_tensors='pt')
    outputs = model.generate(inputs, max_length=50, num_return_sequences=1)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response
